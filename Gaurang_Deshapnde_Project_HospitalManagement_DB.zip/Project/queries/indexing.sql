CREATE UNIQUE INDEX person_for_patient ON patient (person_id);

CREATE UNIQUE INDEX person_for_staff ON staff (person_id);